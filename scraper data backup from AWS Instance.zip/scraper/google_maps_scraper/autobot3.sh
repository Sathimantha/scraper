python3 main.py -s="London paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Milton Keynes paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Edinburgh paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Belfast paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Glasgow paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Bristol paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Peterborough paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Nottingham paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Leeds paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Derby paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Portsmouth paralegal" -t=40 -d="UK_Law2"
python3 main.py -s="Brighton & Hove paralegal" -t=40 -d="UK_Law2"
zip -r UK_Law2.zip out/UK_Law2

